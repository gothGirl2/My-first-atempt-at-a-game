﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace myGame1
{
    /// <summary>
    /// all types of boxes used for hit registration
    /// </summary>
    abstract class Boxes 
    {
        protected bool isAlive;
        protected Rectangle rectangle;
        protected Vector2 position;
        /// <summary>
        /// position is relativ to the player
        /// </summary>
        /// <param name="posX"></param>
        /// <param name="posY"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        public Boxes(int posX, int posY,int width, int height)
        {
            position.X = posX;
            position.Y = posY;
            rectangle.Width = width;
            rectangle.Height = height;
            isAlive = true;
        }
        public bool CheckCollision(Boxes other)
        {
            Rectangle myRect = new Rectangle(rectangle.X,rectangle.Y,rectangle.Width,rectangle.Height);
            
            Rectangle otherRec = new Rectangle(other.rectangle.X, other.rectangle.Y, other.rectangle.Width, other.rectangle.Height);

            return myRect.Intersects(otherRec);
        }
        public virtual void Update(int X, int Y, GameTime gameTime)
        {
            rectangle.X = X+ (int)position.X;
            rectangle.Y = Y+(int)position.Y;
        }
        public Rectangle Rectangle
        {
            get { return rectangle; }
            set { rectangle = value; }
        }

    }
    /// <summary>
    /// Boxes thrown by an attacker to check for hit
    /// </summary>
    class HitBoxes : Boxes
    {
        public enum HitState { AttackHigh, AttackLow, AttackMid, Inactive, Used};
        protected HitState state;
        protected Vector2 knockback;
        protected int damage;
        
        public HitBoxes (int posX, int posY, int width, int height, int knockbackX,int knockbackY,int damage) : base(posX, posY, width, height)
        {
            
            knockback.X = knockbackX;
            knockback.Y = knockbackY;
            this.damage = damage;
        }
        public override void Update(int X, int Y, GameTime gameTime)
        {
            base.Update(X, Y, gameTime);
        }
        public int Damage
        {
            get { return damage; }
        }
        public Vector2 KnockBack
        {
            get { return knockback; }
        }
        public bool IsAlive
        {
            get { return isAlive; }
            set { isAlive = value; }
        }
        public HitState State
        {
            get { return state; }
            set { state = value; }
        }
    }
    /// <summary>
    /// Boxes every player has as a collision for attacks
    /// </summary>
    class HurtBoxes : Boxes
    {
        public enum HurtState { Vulnerable, InVulnerable, InTangible, Attacking, Dodging, BlockHigh, BlockLow, HitStun, Recouvery };
        protected HurtState state;
        public HurtBoxes(int width, int height, HurtState state) : base(0,0, width, height)
        {
            this.state = state;
        }

        public HurtState State
        {
            get { return state; }
            set { state = value; }
        }
    }
    /// <summary>
    /// attacks are created by players
    /// </summary>
    class Attack
    {
        HitBoxes hitBox;
        List<double> time = new List<double>();
        HitBoxes.HitState type;
        // this is to easier be able to say when to spawn/despawn hitboxes aswell as getting character out of the attacking state
        //0 == start up animation prior to the hitboxes spawning
        //1 == the time while the hitboxes are out
        //2 == the recouvery after the hitboxes despawn
        short movePart;
        public Attack(HitBoxes hitBox, double startUp, double duration, double recovery, HitBoxes.HitState type, GameTime startTime)
        {
            this.hitBox = hitBox;
            time.Add(startUp);
            time.Add(startUp + duration);
            time.Add(startUp + duration + recovery);
            this.type = type;
        }
        public void Create(HitBoxes hitBox, double startUp, double duration, double recovery, HitBoxes.HitState type, GameTime startTime)
        {
            this.hitBox = hitBox;

            time[0]=startUp + startTime.TotalGameTime.TotalMilliseconds;
            time[1]=startUp + duration + startTime.TotalGameTime.TotalMilliseconds;
            time[2]=startUp + duration + recovery + startTime.TotalGameTime.TotalMilliseconds;

            movePart = 0;

            this.type = type;
        }


        public void Update(int X, int Y,GameTime gameTime)
        {
            
            if (movePart == 0)
            {
                if (time[0] < gameTime.TotalGameTime.TotalMilliseconds)
                {
                    movePart++;
                }
                else
                {
                    hitBox.State = type;
                }
            }
            else if (movePart == 1)
            {
                if (time[1] < gameTime.TotalGameTime.TotalMilliseconds)
                {
                    movePart++;
                }
                else
                {
                    hitBox.Update(X, Y, gameTime);
                }
            }
            else if (movePart == 2)
            {
                if (time[2] < gameTime.TotalGameTime.TotalMilliseconds)
                {
                    movePart++;
                }
            }
            else if (movePart > 2)
            {
                hitBox = null;
            }
        }

        public HitBoxes AttackBox
        {
            get { return hitBox; }
        }
    }
}
