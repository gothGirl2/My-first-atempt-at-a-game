﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
namespace myGame1
{
    /// <summary>
    /// This is the super class for all the character that are in the game (currently there is only one)
    /// </summary>
    abstract class Character
    {
        protected int maxHealth;
        protected double currentHealth;
        protected Vector2 position;
        protected Vector2 speed;
        protected Vector2 knockBack;
        protected Texture2D texture;
        protected HitBoxes hitBox;
        protected HurtBoxes hurt;
        protected Attack attack;
        Rectangle spriteSource;
        Color plColor;
        public Character(Texture2D texture, int m, int X, int Y, int speedX, int speedY, Color color)
        {
            this.texture = texture;
            maxHealth = m;
            currentHealth = m;
            position.X = X;
            position.Y = Y;
            speed.X = speedX;
            speed.Y = speedY;
            spriteSource.Width = 44;
            spriteSource.Height = 56;
            spriteSource.X = 5;
            spriteSource.Y = 5;
            hurt = new HurtBoxes( 44, 56, HurtBoxes.HurtState.Vulnerable);
            attack = new Attack(hitBox, 0, 0, 0, HitBoxes.HitState.Inactive, null);
            plColor = color;
        }
        public HurtBoxes Hurt
        {
            get { return hurt; }
        }

        public void Update(GameTime gameTime)
        {
            spriteSource.X = 5;
            spriteSource.Y = 5;
            if (HurtBoxes.HurtState.HitStun == hurt.State)
            {
                position.X += knockBack.X;
                position.Y -= knockBack.Y;
                knockBack.X *= 0.85f;
                knockBack.Y *= 0.85f;
                if (position.Y >= 399)
                {
                    hurt.State = HurtBoxes.HurtState.Vulnerable;
                }
            }

            if (position.Y < 400)
            {
                speed.Y += 2;
                if (speed.Y + position.Y > 400)
                {
                    speed.Y = 0;
                    position.Y = 400;
                }
                else
                {
                    position.Y += speed.Y;
                    if (speed.Y > 0)
                    {
                        spriteSource.X = 113;
                        spriteSource.Y = 5;
                    }
                    else
                    {
                        spriteSource.X = 59;
                        spriteSource.Y = 5;
                    }
                }
            }
            else
            {
                speed.Y = 0;
                position.Y = 400;
            }

            if (attack.AttackBox != null)
            {
                attack.Update((int)position.X, (int)position.Y, gameTime);
            }
            else if (hurt.State == HurtBoxes.HurtState.Attacking)
            {
                hurt.State = HurtBoxes.HurtState.Vulnerable;
            }
            if (rightBorder())
            {
                knockBack.X *= -1;
                position.X = 800-44;
            }
            if (leftBorder())
            {
                knockBack.X *= -1;
                position.X = 0;
            }

            hurt.Update((int)position.X, (int)position.Y, gameTime);
        }
        public void Draw(SpriteBatch spriteBatch,bool right)
        {
            //spriteBatch.Draw(texture, position);
            Vector2 RightLeft;
            if (right)
            {
                RightLeft = Vector2.One;
                spriteBatch.Draw(texture, position, spriteSource, plColor, 0, Vector2.Zero,RightLeft, SpriteEffects.None, 1);
            }
            else
            {
                RightLeft = Vector2.One;
                spriteBatch.Draw(texture, position, spriteSource, plColor, 0, Vector2.Zero, RightLeft, SpriteEffects.FlipHorizontally,1);
            }
            
        }
        public void Right()
        {
            if (Hurt.State == HurtBoxes.HurtState.Vulnerable&& !rightBorder())
            {
                position.X += speed.X;
            }
            spriteSource.X = 5;
            spriteSource.Y = 71;
        }
        public void Left()
        {
            if (Hurt.State == HurtBoxes.HurtState.Vulnerable)
            {
                position.X -= speed.X;
            }
            spriteSource.X = 5;
            spriteSource.Y = 71;
        }

        public void Jump()
        {
            if (Hurt.State == HurtBoxes.HurtState.Vulnerable)
            {
                speed.Y = -25f;
                position.Y += speed.Y;
            }
        }

        public void GetKnockBack(float knockbackX, float knockbackY, GameTime gameTime)
        {
            knockBack.X = knockbackX;
            knockBack.Y = knockbackY;
            hurt.State = HurtBoxes.HurtState.HitStun;
        }

        protected bool rightBorder()
        {
            if (position.X >= (800 - 44))
            {
                return true;
            }
            return false;
        }

        protected bool leftBorder()
        {
            if (position.X <= 0)
            {
                return true;
            }
            return false;
        }

        public double Health
        {
            get { return currentHealth; }
            set { currentHealth = value; }
        }
        public HitBoxes AttackBox
        {
            get { return attack.AttackBox; }
        }

        public double MaxHealth
        {
            get { return maxHealth; }
        }

        public virtual void attackSide(bool right, GameTime gameTime) { }

        public virtual void attackNeutral(bool right, GameTime gameTime) { }

        public virtual void attackUp(bool right, GameTime gameTime) { }

        public virtual void attackDown(bool right, GameTime gameTime) { }

        public virtual void airDown(bool right, GameTime gameTime) { }

        public virtual void airUp(bool right, GameTime gameTime) { }

        public virtual void airSide(bool right, GameTime gameTime) { }

        public virtual void airNeutral(bool right, GameTime gameTime) { }
        public void reset(int X, int Y)
        {
            currentHealth = maxHealth;
            position.X = X;
            position.Y = Y;
        }
    }

    class JoeGunman : Character
    {
        public JoeGunman(Texture2D texture, int m, int X, int Y, Color color) : base(texture, m, X, Y, 5, 5, color) { }

        //creating all the attacks

        public override void attackDown(bool right, GameTime gameTime)
        {
            if (position.Y < 400)
            {
                airDown(right, gameTime);
            }
            else
            {


                hitBox = new HitBoxes(-24, 56 - 10, 44 + 48, 10, -0, 30, 30);
                attack.Create(hitBox, 150, 200, 150, HitBoxes.HitState.AttackMid, gameTime);
                Hurt.State = HurtBoxes.HurtState.Attacking;

            }
        }

        public override void attackSide(bool right, GameTime gameTime)
        {
            if (position.Y < 400)
            {
                airSide(right, gameTime);
            }
            else
            {
                if (right)
                {
                    hitBox = new HitBoxes(-24, 56 - 10, 44 + 48, 10, 30, 30, 60);
                    attack.Create(hitBox, 150, 200, 150, HitBoxes.HitState.AttackMid, gameTime);
                    Hurt.State = HurtBoxes.HurtState.Attacking;
                }
                else
                {
                    hitBox = new HitBoxes(-24, 56 - 10, 44 + 48, 10, -30, 30, 60);
                    attack.Create(hitBox, 150, 200, 150, HitBoxes.HitState.AttackMid, gameTime);
                    Hurt.State = HurtBoxes.HurtState.Attacking;
                }
            }
        }


        //done
        public override void attackNeutral(bool right, GameTime gameTime)
        {
            if (position.Y < 400)
            {
                airNeutral(right, gameTime);
            }
            else
            {
                attackSide(right,gameTime);
            }
        }
        public override void attackUp(bool right, GameTime gameTime)
        {
            if (position.Y < 400)
            {
                airUp(right, gameTime);
            }
            else
            {
                if (right)
                {
                    hitBox = new HitBoxes(44, 56 / 4, 5, 56 / 4 + 10, 4, 20, 45);
                    attack.Create(hitBox, 150, 200, 30, HitBoxes.HitState.AttackMid, gameTime);
                    Hurt.State = HurtBoxes.HurtState.Attacking;
                }
                else
                {
                    hitBox = new HitBoxes(-5, 56 / 4, 5, 56 / 4 + 10, -4, 20, 45);
                    attack.Create(hitBox, 150, 200, 30, HitBoxes.HitState.AttackMid, gameTime);
                    Hurt.State = HurtBoxes.HurtState.Attacking;
                }
            }
        }



        public override void airDown(bool right, GameTime gameTime)
        {
            hitBox = new HitBoxes(44 / 2, 56 - 5, 5, 5, 0, -50, 85);
            attack.Create(hitBox, 10, 200, 150, HitBoxes.HitState.AttackMid, gameTime);
            Hurt.State = HurtBoxes.HurtState.Attacking;
        }



        public override void airUp(bool right, GameTime gameTime)
        {
            if (right)
            {
                hitBox = new HitBoxes(-24, -15, 44 + 48, 25, -5, 5, 40);
                attack.Create(hitBox, 150, 200, 400, HitBoxes.HitState.AttackMid, gameTime);
                Hurt.State = HurtBoxes.HurtState.Attacking;
            }
            else
            {
                hitBox = new HitBoxes(-24, -15, 44 + 48, 25, 5, 5, 40);
                attack.Create(hitBox, 150, 200, 400, HitBoxes.HitState.AttackMid, gameTime);
                Hurt.State = HurtBoxes.HurtState.Attacking;
            }
        }



        public override void airSide(bool right, GameTime gameTime)
        {
            if (right)
            {
                hitBox = new HitBoxes(44, -10, 15, 56 + 15, 15, 30, 60);
                attack.Create(hitBox, 50, 100, 100, HitBoxes.HitState.AttackMid, gameTime);
                Hurt.State = HurtBoxes.HurtState.Attacking;
            }
            else
            {
                hitBox = new HitBoxes(-15, 56 - 10, 15, 15, 15, 30, 60);
                attack.Create(hitBox, 50, 100, 100, HitBoxes.HitState.AttackMid, gameTime);
                Hurt.State = HurtBoxes.HurtState.Attacking;
            }
        }



        public override void airNeutral(bool right, GameTime gameTime)
        {
            if (right)
            {
                hitBox = new HitBoxes(-3, -5, 44 + 6, 56 + 10, 15, 0, 20);
                attack.Create(hitBox, 150, 200, 150, HitBoxes.HitState.AttackMid, gameTime);
                Hurt.State = HurtBoxes.HurtState.Attacking;
            }
            else
            {
                hitBox = new HitBoxes(-3, -5, 44 + 6, 56 + 10, -15, 0, 20);
                attack.Create(hitBox, 150, 200, 150, HitBoxes.HitState.AttackMid, gameTime);
                Hurt.State = HurtBoxes.HurtState.Attacking;
            }
        }
    }
}
