﻿using System;
using System.IO;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
namespace myGame1
{
    static class GameElements
    {
        static Player pl1;
        static Player pl2;
        static PrintText printText;
        static string LastMatch;
        static Texture2D background;
        static Texture2D healthBar;
        public enum State { Menu, Run, Score, Quit, CharacterSelect , WinScreen, Tutorial};
        public static State state = State.Menu;

        public static void LoadContent(ContentManager content, GameWindow window)
        {
            pl2 = new Player(new JoeGunman(content.Load<Texture2D>("pl1Sprite"), 700, 700, 400, Color.Blue),Keys.Right,Keys.Left,Keys.Up,Keys.NumPad0,Keys.RightControl);
            pl1 = new Player(new JoeGunman(content.Load<Texture2D>("pl1Sprite"), 700, 100, 400, Color.Red),Keys.D,Keys.A,Keys.W,Keys.Space,Keys.Q);
            printText = new PrintText(content.Load<SpriteFont>("Font"));
            LastMatch = "WAIT";
            background = content.Load<Texture2D>("Background");
            healthBar = content.Load<Texture2D>("Health Bar");
        }
        public static void Update(GameTime gameTime)
        {
            if (GameElements.state == GameElements.State.Menu)
            {
                state = GameElements.MenuUpdate(gameTime);
            }
            else if (GameElements.state == GameElements.State.Run)
            {
                state = GameElements.RunUpdate(gameTime);
            }
            else if (GameElements.state == GameElements.State.WinScreen)
            {
                state = GameElements.WinUpdate(gameTime);
            }
            else if (GameElements.state == GameElements.State.CharacterSelect)
            {
                state = GameElements.CharSelUpdate(gameTime);
            }
            else if (GameElements.state == GameElements.State.Score)
            {
                state = GameElements.MatchHistoryUpdate(gameTime);
            }
            else if ( GameElements.state == GameElements.State.Tutorial)
            {
                state = GameElements.TutorialUpdate(gameTime);
            }
        }
        public static State MenuUpdate(GameTime gameTime)
        {
            KeyboardState keyboardState = Keyboard.GetState();

            if (keyboardState.IsKeyDown(Keys.S))
            {
                
                return State.CharacterSelect;
            }
            else if (keyboardState.IsKeyDown(Keys.H))
            {
                return State.Score;
            }
            else if (keyboardState.IsKeyDown(Keys.Escape))
            {
                return State.Quit;
            }
            else if (keyboardState.IsKeyDown(Keys.T))
            {
                return State.Tutorial;
            }
            return state;
        }
        public static State CharSelUpdate(GameTime gameTime)
        {
            //KeyboardState keyboardState = Keyboard.GetState();


            //if (keyboardState.IsKeyDown(Keys.Enter))
            //{
            //    return State.Run;
            //}
            //if (keyboardState.IsKeyDown(Keys.Escape))
            //{
            //    return State.Menu;
            //}
            //return state;
            return State.Run;
        }
        public static State RunUpdate(GameTime gameTime)
        {
            KeyboardState keyboardState = Keyboard.GetState();
            pl1.Update(gameTime, keyboardState);
            pl2.Update(gameTime, keyboardState);

            bool hit = false;
            if (pl1.Character.AttackBox != null)
            {
                if (pl1.Character.AttackBox.CheckCollision(pl2.Character.Hurt) && pl1.Character.AttackBox.IsAlive)
                {
                    pl2.Character.Health -= pl1.Character.AttackBox.Damage;
                    pl2.Character.GetKnockBack(pl1.Character.AttackBox.KnockBack.X, pl1.Character.AttackBox.KnockBack.Y, gameTime);
                    hit = true;
                }
            }
            if (pl2.Character.AttackBox != null)
            {
                if (pl2.Character.AttackBox.CheckCollision(pl1.Character.Hurt) && pl2.Character.AttackBox.IsAlive)
                {
                    pl1.Character.Health -= pl2.Character.AttackBox.Damage;
                    pl1.Character.GetKnockBack(pl2.Character.AttackBox.KnockBack.X, pl2.Character.AttackBox.KnockBack.Y, gameTime);
                    hit = true;
                }
            }
            if (hit && pl1.Character.AttackBox != null)
            {
                pl1.Character.AttackBox.IsAlive = false;
            }
            if (hit && pl2.Character.AttackBox != null)
            {
                pl2.Character.AttackBox.IsAlive = false;
            }



            if (pl1.Character.Health <= 0||pl2.Character.Health <=0)
            {
                StreamWriter sw = new StreamWriter("Match scores.txt", true);

                if (pl1.Character.Health <= 0 || pl2.Character.Health <= 0)
                {
                    sw.WriteLine("Player 1: " + pl1.Character.Health.ToString() + "   Player 2: " + pl2.Character.Health.ToString());
                    if (pl1.Character.Health <= 0 && pl2.Character.Health <= 0)
                    {
                        LastMatch = "DRAW";
                    }
                    else if (pl1.Character.Health <= 0)
                    {
                        LastMatch = "PLAYER TWO WINS";
                    }
                    else if (pl2.Character.Health <= 0)
                    {
                        LastMatch = "PLAYER ONE WINS";
                    }
                }
                sw.Close();
                pl1.Character.reset(100, 400);
                pl2.Character.reset(700, 400);
                return State.WinScreen;
            }
            return state;
        }
        public static State WinUpdate(GameTime gameTime)
        {
            KeyboardState keyboardState = Keyboard.GetState();
            if (keyboardState.IsKeyDown(Keys.Enter))
            {
                return State.Menu;
            }
            return state;
        }
        public static State MatchHistoryUpdate(GameTime gameTime)
        {
            KeyboardState keyboardState = Keyboard.GetState();

            if (keyboardState.IsKeyDown(Keys.Enter))
            {
                return State.Menu;
            }
            return state;
        }
        public static State TutorialUpdate(GameTime gameTime)
        {
            KeyboardState keyboardState = Keyboard.GetState();

            if(keyboardState.IsKeyDown(Keys.Enter))
            {
                return State.Menu;
            }
            return state;
        }
        public static void RunDraw(SpriteBatch spriteBatch)
        {
            Rectangle temp;
            temp.Width=400;
            temp.Height = 230;
            temp.X = 0;
            temp.Y = 0;
            spriteBatch.Draw(background, Vector2.Zero, temp, Color.White, 0, Vector2.Zero, 2, SpriteEffects.None, 0);
            pl1.Draw(spriteBatch);
            pl2.Draw(spriteBatch);
            
            Rectangle pl1Healthbar = new Rectangle((int)(350.0 * (pl1.Character.Health / pl1.Character.MaxHealth)), 0, 350, 20);
            spriteBatch.Draw(healthBar, new Vector2(5, 5), pl1Healthbar,Color.White,0,Vector2.Zero,1,SpriteEffects.FlipHorizontally,0);
            Rectangle pl2Healthbar = new Rectangle((int)(350.0 * (pl2.Character.Health / pl2.Character.MaxHealth)), 0, 350, 20);
            spriteBatch.Draw(healthBar, new Vector2(800-355, 5), pl2Healthbar, Color.White, 0, Vector2.Zero, 1, SpriteEffects.None, 0);
        }
        public static void MenuDraw(SpriteBatch spriteBatch)
        {
            printText.Print("Play (S)", spriteBatch, 0, 0);
            printText.Print("Match History (H)", spriteBatch, 0, 20);
            printText.Print("Tutorial (T)", spriteBatch, 0, 40);
            printText.Print("Quit (ESC)", spriteBatch, 0, 60);
        }
        public static void WinScreenDraw(SpriteBatch spriteBatch)
        {
            printText.Print(LastMatch, spriteBatch, 300, 200);        
        }
        public static void MatchHistoryDraw(SpriteBatch spriteBatch)
        {
            StreamReader sr = new StreamReader("Match scores.txt");
            string row = sr.ReadLine();
            int i = 0;
            while (row != null) 
            {
                printText.Print(row, spriteBatch, 0, (i * 20));
                i++;
                row = sr.ReadLine();
            }

                sr.Close();
        }
        public static void TutorialDraw(SpriteBatch spriteBatch)
        {
            printText.Print("Player one:", spriteBatch, 10, 10);
            printText.Print("A = LEFT : D = RIGHT : W = UP : Q = ATTACK : SPACE = JUMP", spriteBatch, 10, 30);
            printText.Print("Player two:", spriteBatch, 10, 50);
            printText.Print("Left Arrow = LEFT : Right Arrow = RIGHT : Up Arrow = UP : Right Control = ATTACK : Numpad 0 = JUMP", spriteBatch, 10, 70);
        }
    }
}
