﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;


namespace myGame1
{
    
    class Player
    {
        protected bool right;
        protected Character character;
        
        // order: Right, Left, Up, Jump, Attack
        protected List<Keys> keys;
        public Player(Character character, Keys right, Keys left, Keys up, Keys jump, Keys attack)
        {
            this.character = character;
            keys = new List<Keys>() { right, left, up, jump, attack };
            this.right = true;
            
        }
        public void Update(GameTime gameTime, KeyboardState keyboardState)
        {
            character.Update(gameTime);
            if (character.Hurt.State == HurtBoxes.HurtState.Vulnerable)
            {
                if (keyboardState.IsKeyDown(keys[0]))
                {
                    if (keyboardState.IsKeyDown(keys[1]))
                    {
                        if (keyboardState.IsKeyDown(keys[4]))
                        {
                            character.attackNeutral(right, gameTime);
                        }
                    }
                    else
                    {
                        right = true;
                        character.Right();
                        if (keyboardState.IsKeyDown(keys[4]))
                        {
                            character.attackSide(right, gameTime);
                        }
                    }
                }
                else if (keyboardState.IsKeyDown(keys[1]))
                {
                    if (keyboardState.IsKeyDown(keys[0]))
                    {
                        if (keyboardState.IsKeyDown(keys[4]))
                        {
                            character.attackNeutral(right, gameTime);
                        }
                    }
                    else
                    {
                        right = false;
                        character.Left();
                        if (keyboardState.IsKeyDown(keys[4]))
                        {
                            character.attackSide(right, gameTime);
                        }
                    }
                }
                else if (keyboardState.IsKeyDown(Keys.S) && keyboardState.IsKeyDown(keys[4]))
                {
                    character.attackDown(right, gameTime);
                }
                else if (keyboardState.IsKeyDown(keys[2]) && keyboardState.IsKeyDown(keys[4]))
                {
                    character.attackUp(right, gameTime);
                }
                else
                {
                    if (keyboardState.IsKeyDown(keys[4]))
                    {
                        character.attackNeutral(right, gameTime);
                    }
                }
                if (keyboardState.IsKeyDown(keys[3]) && character.Hurt.Rectangle.Y == 400)
                {
                    character.Jump();
                }

            }

        }
        public void Draw(SpriteBatch spriteBatch)
        {
            character.Draw(spriteBatch, right);
        }
        public Character Character
        {
            get { return character; }
        }
        public HurtBoxes Hurt
        {
            get { return character.Hurt; }
        }
    }
}


